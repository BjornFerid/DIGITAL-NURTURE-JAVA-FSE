package SingletonPatternExample;

public class Logger {
    // Private static instance of Logger (eager or lazy initialization can be used)
    private static Logger instance;

    // Private constructor to prevent external instantiation
    private Logger() {
        System.out.println("Logger initialized.");
    }

    // Public static method to return the singleton instance
    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    // A logging method for demonstration
    public void log(String message) {
        System.out.println("Log: " + message);
    }
}
