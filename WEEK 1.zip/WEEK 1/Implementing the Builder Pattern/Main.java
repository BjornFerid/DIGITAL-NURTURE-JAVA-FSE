package BuilderPatternExample;

public class Main {
    public static void main(String[] args) {
       
        Computer officePC = new Computer.Builder()
                .setCPU("Intel i3")
                .setRAM("8GB")
                .setStorage("256GB SSD")
                .build();

        System.out.println("Office PC Config:");
        System.out.println(officePC.getSpecs());

        
        Computer gamingPC = new Computer.Builder()
                .setCPU("Intel i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 4080")
                .setDisplay("4K 144Hz Monitor")
                .build();

        System.out.println("\nGaming PC Config:");
        System.out.println(gamingPC.getSpecs());
    }
}
