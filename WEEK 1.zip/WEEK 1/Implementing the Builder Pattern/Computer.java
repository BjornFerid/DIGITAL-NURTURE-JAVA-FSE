package BuilderPatternExample;

public class Computer {
    
    private String CPU;
    private String RAM;
    private String storage;
    private String graphicsCard;
    private String display;

    
    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.graphicsCard = builder.graphicsCard;
        this.display = builder.display;
    }

    
    public String getSpecs() {
        return "CPU: " + CPU + ", RAM: " + RAM + ", Storage: " + storage +
               ", Graphics: " + graphicsCard + ", Display: " + display;
    }

    
    public static class Builder {
        private String CPU;
        private String RAM;
        private String storage;
        private String graphicsCard;
        private String display;

        public Builder setCPU(String CPU) {
            this.CPU = CPU;
            return this;
        }

        public Builder setRAM(String RAM) {
            this.RAM = RAM;
            return this;
        }

        public Builder setStorage(String storage) {
            this.storage = storage;
            return this;
        }

        public Builder setGraphicsCard(String graphicsCard) {
            this.graphicsCard = graphicsCard;
            return this;
        }

        public Builder setDisplay(String display) {
            this.display = display;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }
}
