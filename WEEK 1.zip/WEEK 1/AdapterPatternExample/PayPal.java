package AdapterPatternExample;

public class PayPal {
    public void sendPayment(double amount) {
        System.out.println("Paid ₹" + amount + " using PayPal.");
    }
}
